package com.uday.operators;

public class RelationalOperatorsExample {

	public static void main(String[] args) {
		
		// Relational Operators like ("> , >=, <, <=, ==, !=)
		
		int a=10;
		int b=20;
		
		System.out.println("Result of > operaror (a>b) is :"+(a>b));
		
		System.out.println("Result of >= operaror (a>=b) is :"+(a>=b));
		
		System.out.println("Result of < operaror  (a<b) is :"+(a<b));
		
		System.out.println("Result of < operaror (a<=b) is :"+(a<=b));
		
		System.out.println("Result of  == operator (a==b) is :"+(a==b));
		
		System.out.println("Result of  != operator (a!=b) is :"+(a!=b));

	}

}
