package com.uday.operators;

public class ArthimaticOperatorsExample {

	//Arithmetic operators like (+ , - , * ,/ , %)
	
	public static void main(String[] args) {
		
	int a=15;
	int b=10;
	
	System.out.println("Arithmatic Operators Examples in Below");
	System.out.println("=======================================");
	System.out.println("Result of  + operator is :" + (a+b));
	System.out.println("Result of  - operator is :" + (a-b));
	System.out.println("Result of  * operator is :" + (a*b));
	System.out.println("Result of  / operator is :" + (a/b));
	System.out.println("Result of  % operator is :" + (a%b));
	
	
}

}