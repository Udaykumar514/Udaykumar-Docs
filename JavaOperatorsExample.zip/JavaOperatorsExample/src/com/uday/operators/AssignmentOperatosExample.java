package com.uday.operators;

public class AssignmentOperatosExample {

	public static void main(String[] args) {
	
		// Assignment Operator like (=)
		
		int a = 5;
		System.out.println("Assignment = operator like ::" + a);

	}

}
