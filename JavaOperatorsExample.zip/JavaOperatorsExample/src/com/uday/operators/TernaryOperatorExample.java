package com.uday.operators;

public class TernaryOperatorExample {

	public static void main(String[] args) {
		
		// Ternary Operator or Conditional Operator
		byte a=5;
		byte b=10;
			
		System.out.println((a>b) ? "a is greater than b " : "a is less than b"); //The condition is checking is condition is true (?) next statement is executed or else (:) next statement is executed
		
		System.out.println((a>b) ? "a is big" : "a is small");
		
		//The condition is checking is condition is true (?) next statement is executed or else (:) next statement is executed
	}

}


//==============================================The-End=======================================================================